package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class VerDatos : AppCompatActivity() {

    var nombre: String? = null
    var edad:Int = 0
    var email:String? = null
    var c: Empleado? = null
    val TAG : String ="AltasActivity"


    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_datos)

        c = intent.getSerializableExtra("objeto") as Empleado?
        Log.d(TAG, "RELLENANDO DATOS")
        rellenardatos(c!!)
        Log.d(TAG, "DATOS RELLENOS")
        val btSalir : Button = findViewById(R.id.bt_salir)

        btSalir.setOnClickListener(){
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("objeto", c as Serializable)
            startActivity(intent)
        }
    }

    fun rellenardatos(per: Empleado) {
        if (!per.getNombre().equals("")) {
            val txtNombre = findViewById<View>(R.id.txNombre) as TextView
            val txtEdad = findViewById<View>(R.id.txEdad) as TextView
            val txtEmail = findViewById<View>(R.id.txEmail) as TextView
            val txtRegistrado = findViewById<View>(R.id.txtRegistrado) as TextView
            val txtsueldo = findViewById<View>(R.id.txtSueldo) as TextView
            val txtAdjetivo= findViewById<View>(R.id.txtAdjetivo) as TextView
            txtNombre.text = "Nombre: " + c!!.getNombre()
            txtEmail.text = "Email: " + c!!.getEmail()
            txtEdad.text = "Edad: " + c!!.getEdad()
            txtsueldo.text = "Sueldo: " + c!!.getSueldo()
            txtAdjetivo.text= ""+c!!.getAdjetivo()
            if (c!!.isRegistrado()) {
                txtRegistrado.text = "Ya estaba registrado"
            } else {
                txtRegistrado.text = "Es la primera vez que se registra"
            }
        }
    }

}