package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class Registrarse : AppCompatActivity() {


    var c: Empleado? = null
    val TAG : String ="RegistroActivity"
    lateinit var check: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrarse)

        c = intent.getSerializableExtra("objeto") as Empleado?
        val btAceptar : Button = findViewById(R.id.btAceptarReg)

        btAceptar.setOnClickListener{
            try{
                check = findViewById<View>(R.id.cbRegistrar) as CheckBox
                c!!.setRegistrado(check.isChecked())

                val cambiarMain = Intent(this, MainActivity::class.java)
                cambiarMain.putExtra("objeto", c as Serializable?)
                startActivity(cambiarMain)
            }catch (e : Exception){
                Log.e(TAG,"ERROR" + e.message)
            }
        }
    }
}