package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class sueldo : AppCompatActivity() {
    val TAG : String ="SueldoActivity"
    var c: Empleado? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sueldo)
        c = intent.getSerializableExtra("objeto") as Empleado?
        val btAceptar : Button = findViewById(R.id.btAcept)
        val btSalir : Button = findViewById(R.id.btSalirSueldo)
        var sp : Spinner=findViewById(R.id.spSueldo)

        Log.d(TAG, "Rellenando Spinner")
        val adapter = ArrayAdapter.createFromResource(this, R.array.sp, android.R.layout.simple_spinner_item)
        sp.adapter = adapter
        Log.d(TAG, "Spinner relleno")


        btSalir.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("objeto", c as Serializable)
            startActivity(intent)
        }

        btAceptar.setOnClickListener{
            val sueldo = sp.selectedItem.toString().toInt()
            c!!.setSueldo(sueldo)
            val cambiarMain = Intent(this, MainActivity::class.java)
            cambiarMain.putExtra("objeto", c as Serializable?)
            startActivity(cambiarMain)
        }
    }
}