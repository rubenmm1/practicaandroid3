package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class Descripcion : AppCompatActivity() {
    var c: Empleado? = null


    lateinit var rb1: RadioButton
    lateinit var rb2:RadioButton
    lateinit var rb3: RadioButton
    lateinit var rb4:RadioButton
    lateinit var rb5: RadioButton
    lateinit var rb6:RadioButton
    lateinit var rb7: RadioButton


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_descripcion)

        c = intent.getSerializableExtra("objeto") as Empleado?
        val btAceptar : Button = findViewById(R.id.btAceptarDesc)

        btAceptar.setOnClickListener(){
            rb1 = findViewById<View>(R.id.rb1) as RadioButton
            rb2 = findViewById<View>(R.id.rb2) as RadioButton
            rb3 = findViewById<View>(R.id.rb3) as RadioButton
            rb4 = findViewById<View>(R.id.rb44) as RadioButton
            rb5 = findViewById<View>(R.id.rb5) as RadioButton
            rb6 = findViewById<View>(R.id.rb6) as RadioButton
            rb7 = findViewById<View>(R.id.rb7) as RadioButton

            rellenar()?.let { it1 -> c!!.setAdejtivo(it1) }

            val cambiarMain = Intent(this, MainActivity::class.java)
            cambiarMain.putExtra("objeto", c as Serializable?)
            startActivity(cambiarMain)
        }
    }

    fun rellenar(): String? {
        var cad: String? = ""
        if (rb1.isChecked) {
            cad += rb1.text
        }
        if (rb2.isChecked) {
            cad += rb2.text
        }
        if (rb3.isChecked) {
            cad += rb3.text
        }
        if (rb4.isChecked) {
            cad += rb4.text
        }
        if (rb5.isChecked) {
            cad += rb5.text
        }
        if (rb6.isChecked) {
            cad += rb6.text
        }
        if (rb7.isChecked) {
            cad += rb7.text
        }
        return cad
    }
}