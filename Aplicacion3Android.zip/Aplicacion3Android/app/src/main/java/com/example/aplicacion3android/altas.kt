package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class altas : AppCompatActivity() {

    val TAG : String ="AltasActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_altas)
        val btAceptar : Button = findViewById(R.id.btAceptar)
        val btCancelar : Button = findViewById(R.id.btCancelar)

        btAceptar.setOnClickListener(){


            val editNombre : EditText = findViewById(R.id.editNombre)
            val editEdad : EditText = findViewById(R.id.editEdad)
            val editEmail : EditText = findViewById(R.id.editemail)


            try{
                var nombre = editNombre.text.toString()
                var edad = editEdad.text.toString().toInt()
                var email = editEmail.text.toString()

                val cambiar = Intent(this, MainActivity::class.java)
                val c = Empleado(nombre, email, edad)
                cambiar.putExtra("objeto", c as Serializable)
                startActivity(cambiar)
            } catch (e : Exception){
                Log.e(TAG,"ERROR" + e.message)
            }


        }

        btCancelar.setOnClickListener(){

            try{
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            } catch (e : Exception){
                Log.e(TAG,"ERROR" + e.message)
            }

        }
    }
}