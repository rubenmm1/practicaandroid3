package com.example.aplicacion3android

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class MainActivity : AppCompatActivity() {

    var c: Empleado? = null
    val TAG : String ="MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

         c = intent.getSerializableExtra("objeto")as Empleado?

        val btAlta : Button = findViewById(R.id.bt_altas)
        val btMostrar : Button = findViewById(R.id.bt_mostrar)
        val btSalir : Button = findViewById(R.id.bt_Salir)
        val btRegistrarse : Button = findViewById(R.id.btRegistrarse)
        val btsueldo : Button = findViewById(R.id.bt_sueldo)
        val btDescripcion : Button = findViewById(R.id.bt_Descripcion)

        btSalir.setOnClickListener{onDestroy()}
        btAlta.setOnClickListener{cambiarAltas()}
        btMostrar.setOnClickListener{cambiarMostrar()}
        btRegistrarse.setOnClickListener{cambiarRegistrado()}
        btsueldo.setOnClickListener{cambiarSueldo()}
        btDescripcion.setOnClickListener{cambiarDescripcion()}
    }

    fun cambiarAltas(){
        val intent = Intent(this, altas::class.java)
        startActivity(intent)
    }

    fun cambiarMostrar(){
        if(c != null){
            val mostrar = Intent(this@MainActivity, VerDatos::class.java)
            mostrar.putExtra("objeto", c as Serializable?)
            startActivity(mostrar)
        } else {
            println("Debe insertar datos primero")
        }
    }

    fun cambiarRegistrado(){
        if(c != null){
            val mostrar = Intent(this@MainActivity, Registrarse::class.java)
            mostrar.putExtra("objeto", c as Serializable?)
            startActivity(mostrar)
        } else {
            println("Debe insertar datos primero")
        }
    }

    fun cambiarSueldo(){
        if(c != null){
            val mostrar = Intent(this@MainActivity, sueldo::class.java)
            mostrar.putExtra("objeto", c as Serializable?)
            startActivity(mostrar)
        } else {
            println("Debe insertar datos primero")
        }
    }

    fun cambiarDescripcion(){
        if(c != null){
            val mostrar = Intent(this, Descripcion::class.java)
            mostrar.putExtra("objeto", c as Serializable?)
            startActivity(mostrar)
        } else {
            println("Debe insertar datos primero")
        }
    }
}