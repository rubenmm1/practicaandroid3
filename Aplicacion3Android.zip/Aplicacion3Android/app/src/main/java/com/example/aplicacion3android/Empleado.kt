package com.example.aplicacion3android

import java.io.Serializable

class Empleado(private var nombre : String, private var email : String, private var edad : Int) :
    Serializable {

    private var registrado : Boolean = false
    private var sueldo : Int = 0
    private var adjetivo : String = ""

    fun getNombre(): String {
        return nombre
    }

    fun getAdjetivo(): String {
        return adjetivo
    }

    fun getSueldo() : Int{
        return sueldo
    }

    fun setSueldo(sueldo: Int){
        this.sueldo=sueldo
    }

    fun isRegistrado() : Boolean{
        return registrado
    }

    fun setRegistrado(registrado : Boolean){
        this.registrado=registrado
    }

    fun getEmail(): String {
        return email
    }

    fun getEdad(): Int {
        return edad
    }

    fun setNombre(nombre:String) {
        this.nombre=nombre
    }

    fun setAdejtivo(adjetivo:String) {
        this.adjetivo=adjetivo
    }

    fun setEmail(email:String) {
        this.email=email
    }

    fun setEdad(edad:Int) {
        this.edad=edad
    }
}